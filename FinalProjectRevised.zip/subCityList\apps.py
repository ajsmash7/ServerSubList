from django.apps import AppConfig


class SubcitylistConfig(AppConfig):
    name = 'subCityList'


# import requests

# url = ''
# headers = {'Authorization': 'User.token'}
# r = requests.get(url, headers=headers)
