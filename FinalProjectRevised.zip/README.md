**Server Subordinate City List App**

Now Running on Local Server! 

Heroku App Link for deployment: grey-list-s83.herokuapp.com 

I still need to work out some redirect and reverseMatch url bugs in local before I deploy it to production.

I also want to fix the padding on the style sheet. 

Though, I may have this done before grading, so I wanted to submit the link anyways. 

Tests to come that verify the views render the correct template.

Screenshots:

HomePage
![](Homepage.JPG)

Search for myself: Belle
![](SearchPlayer.JPG)

![](Player DropDown.jpg)

![](SearchBelle.JPG)

![](AddBelle.JPG)

The re-route from Adding Belle was wrong; I've realized I don't understand how the URL namespace is done in Django. 

So I fixed it and added one of my alts, Jacq. Which was successful

!! Note !! I realize that my missing template tests would've caught these errors
Though I still don't understand why it builds on the URL instead of redirects.

![](SuccessfulAdd.JPG)