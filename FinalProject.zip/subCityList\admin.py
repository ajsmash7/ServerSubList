from django.contrib import admin

# Register your models here.
from .models import Player, Subcity

admin.site.register(Player)
admin.site.register(Subcity)
# admin.site.register(User)
