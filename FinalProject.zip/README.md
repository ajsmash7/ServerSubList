**Server Subordinate City List App**

Now Running on Local Server! 

Heroku App Link for deployment: grey-list-s83.herokuapp.com 

I still need to work out some redirect and reverseMatch url bugs in local before I deploy it to production.

I also want to fix the padding on the style sheet. 

Though, I may have this done before grading, so I wanted to submit the link anyways. 

Tests to come that verify the views render the correct template.